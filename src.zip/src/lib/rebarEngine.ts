type ScheduleLine = {
  mark: string;
  location: string;
  requiredLength: string;

  cutLength: string;

  leftFunction: string;
  usedLength: string;
  rightFunction: string;

  check: string;
};